﻿# Package 5 - Material Availability Statement and Editor Response

## Purpose

Provides the point-by-point response letter, material availability inventory, author confirmation checklist, data-availability statement, package validation report, and supporting documentation.

## Evidence boundary

The response states exactly which historical materials are unavailable. It does not claim that reconstructed inputs or newly generated logs are the original historical records.

## Integrity verification

SHA256SUMS.csv lists the byte-level SHA-256 digest and size of every other file in this archive. Paths are relative to the archive root.

## Repository

https://github.com/niqundaye/Frontiers-in-Marine-Science
