﻿# Package 4 - Reproducibility Code, Figures, and Validation

## Purpose

Provides the executable source code, tests, environment specifications, figure-by-figure implementations, processed-data replots, validation reports, and reproducibility instructions.

## Evidence boundary

Figures and numerical outputs are reproducibility artefacts generated from disclosed, public, or explicitly reconstructed inputs. Their provenance is recorded in the included documentation.

## Integrity verification

SHA256SUMS.csv lists the byte-level SHA-256 digest and size of every other file in this archive. Paths are relative to the archive root.

## Repository

https://github.com/niqundaye/Frontiers-in-Marine-Science
