﻿# Package 1 - Reconstructed 31-Province Input and Coefficient Matrix

## Purpose

Provides the processed 31-province input table, the 248-row coefficient matrix, sector-mode coefficients, national constraints, variable definitions, derivation rules, and the code used to build them.

## Evidence boundary

These files are a calibrated reconstruction from disclosed article values and public statistics. They are not the unavailable historical author-side workbook.

## Integrity verification

SHA256SUMS.csv lists the byte-level SHA-256 digest and size of every other file in this archive. Paths are relative to the archive root.

## Repository

https://github.com/niqundaye/Frontiers-in-Marine-Science
