﻿# Package 3 - New 30-Run Optimisation Outputs and Metrics

## Purpose

Provides the complete newly generated 30-run outputs for each algorithm, generation-level logs, decision vectors, objective and constraint values, run metadata, metric definitions, HV/IGD recomputation checks, and the exact frozen configuration.

## Evidence boundary

These are newly executed reproducibility runs based on the public-data surrogate model. They are not the unavailable historical 30-run logs used during manuscript preparation.

## Integrity verification

SHA256SUMS.csv lists the byte-level SHA-256 digest and size of every other file in this archive. Paths are relative to the archive root.

## Repository

https://github.com/niqundaye/Frontiers-in-Marine-Science
