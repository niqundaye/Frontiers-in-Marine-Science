﻿# Package 2 - Official Public Source Data and Calibration

## Purpose

Provides the collected public statistical tables, source catalogue, variable dictionary, public-data workbook, national reconciliation checks, and the acquisition/calibration code.

## Evidence boundary

Official observations are preserved separately from processed proxies and calibrated model inputs. Proxy variables are identified as proxies and are not presented as author-original coefficients.

## Integrity verification

SHA256SUMS.csv lists the byte-level SHA-256 digest and size of every other file in this archive. Paths are relative to the archive root.

## Repository

https://github.com/niqundaye/Frontiers-in-Marine-Science
